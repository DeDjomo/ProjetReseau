'use client';
import MenuBar from "@/components/MenuBar";
import SideBar from "@/components/SideBar";
import WorldMap from "@/components/WorldMap";

export default function Home() {
  return (
    <main>
      <MenuBar />
      <div style={{ display: 'flex', flexDirection: 'row', height: '90vh' , width: '100%'}}>
        <SideBar />
        <WorldMap />
      </div>
    </main>
  );
}
