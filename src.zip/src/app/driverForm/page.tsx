'use client';
import DriverForm from '@/components/DriverForm';
import styles from '@/components/DriverForm.module.css';
export default function DriverFormPage() {
    return (
        <html>
            <body>
                <div id={styles.title}>  
                    <img src="/images/logo.png" alt="logo"  className={styles.iconPhoto}/>
                    <p id={styles.fleetFlow}>
                        FleetFlow
                    </p>
                    <h1>Ajouter un Chauffeur</h1>
                </div>
                <DriverForm/>
            </body>
        </html>
    );
}