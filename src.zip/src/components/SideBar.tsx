'use client';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChartBar,  faList, faTruck, faUser } from '@fortawesome/free-solid-svg-icons'
import styles from './SideBar.module.css'
import { useRouter } from 'next/navigation';

export default function SideBar() {
    const router = useRouter();
    return (
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                height: '90vh',
                width: '450px',
                backgroundColor: '#0D47A1',
                color: 'white',
                borderRadius: '10px',
                }}
        >   
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                width: '100%',
                height: '70vh',
                borderBottom: '1px solid #FF7A00',
            }}
        >
                <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                    onClick={() => router.push('/driverForm')}
                >
                    <FontAwesomeIcon icon={faUser}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                        }}
                    />
                    <h2>Ajouter un chaffeur</h2>
                </div>
                <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                >
                    <FontAwesomeIcon icon={faTruck}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                        }}
                    />
                    <h2>Ajouter un véhicule</h2>
                </div>
                <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                >
                    <FontAwesomeIcon icon={faList}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                        }}
                    />
                    <h2>Liste Des Véhicules</h2>
                </div>
                <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                >
                    <FontAwesomeIcon icon={faList}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                            cursor: 'pointer',
                        }}
                    />
                    <h2>Liste Des Chauffeurs</h2>
                </div>
            </div>
            <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                >
                    <FontAwesomeIcon icon={faChartBar}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                            cursor: 'pointer',
                        }}
                    />
                    <h2>Bilan Des Véhicules</h2>
                </div>
                <div className={styles.sidebarElement}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: 20,
                        cursor: 'pointer',
                        }}
                >
                    <FontAwesomeIcon icon={faChartBar}
                        style={{
                            width: 40,
                            height: 40,
                            color: '#FF7A00',
                            cursor: 'pointer',
                        }}
                    />
                    <h2>Bilan Des Chauffeurs</h2>
                </div>
        </div>
    );
}