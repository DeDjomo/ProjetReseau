'use client';

import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faQuestion, faUser } from '@fortawesome/free-solid-svg-icons';
import styles from './DriverForm.module.css';
import { useState } from 'react';

export default function DriverForm() {
    const [nom, setNom] = useState('');
    const [prenom, setPrenom] = useState('');
    const [autrePrenom, setAutrePrenom] = useState('');
    const [civilité, setCivilité] = useState('');
    const [dateNaissance, setDateNaissance] = useState('');
    const [paysNaissance, setPaysNaissance] = useState('');
    const [villeNaissance, setVilleNaissance] = useState('');
    const [provinceNaissance, setProvinceNaissance] = useState('');
    const [paysNationalite1, setPaysNationalite1] = useState('');
    const [paysNationalite2, setPaysNationalite2] = useState('');
    const [email, setEmail] = useState('');
    const [telephone, setTelephone] = useState('');
    const [telephone2, setTelephone2] = useState('');
    const [pays, setPays] = useState('');
    const [ville, setVille] = useState('');
    const [adresse, setAdresse] = useState('');
    const [nomFlotte, setNomFlotte] = useState('');
    const [service, setService] = useState('');
    const [typePermis, setTypePermis] = useState('');
    const [dateObtention, setDateObtention] = useState('');
    const [permis, setPermis] = useState('');
    
    const handleSubmit = (e: React.FormEvent) => {
           e.preventDefault();
        console.log({
            nom,
            prenom,
            autrePrenom,
            civilité,
            dateNaissance,
            paysNaissance,
            villeNaissance,
            provinceNaissance,
            paysNationalite1,
            paysNationalite2,
            email,
            telephone,
            telephone2,
            pays,
            ville,
            adresse,
            nomFlotte,
            service,
            typePermis,
            dateObtention,
            permis,
        });
    };
    
        return (
        <form className={styles.driverForm} onSubmit={handleSubmit}>
            <div className={styles.informationsPersonnelles}>
                <div className={styles.infosPersonnelles}>
                    <div className={styles.infosPersonnellesdiv}>  
                        <FontAwesomeIcon icon={faPenToSquare} className={styles.divIcon}/>
                        <h2>Informations Personnelles</h2>
                    </div>
                    <div className={styles.photoNomPrenom}>
                        <div className={styles.photo}>
                            <span>Photo</span>
                            <FontAwesomeIcon icon={faUser} className={styles.iconPhoto}/>
                        </div>
                        <div className={styles.nomPrenom}>
                            <div className={styles.nationalite}>
                                <div className={styles.formElement}>
                                    <label htmlFor="name" className={styles.label} aria-required="true">Nom 
                                        <span className={styles.required}>*</span>
                                    </label>
                                    <input type="text" id={styles.name} name="name" className={styles.input}
                                        value={nom}
                                        onChange={(e) => setNom(e.target.value)}
                                        style={{fontSize: '14px', padding: '10px'}}
                                    />
                                </div>
                                <div className={styles.formElement}>
                                    <label htmlFor="prenom" className={styles.label} aria-required="true">Prénom 
                                        <span className={styles.required}>*</span>
                                    </label>
                                    <input type="text" id={styles.prenom} name="prenom" className={styles.input}
                                        value={prenom}
                                        onChange={(e) => setPrenom(e.target.value)}
                                        style={{fontSize: '14px', padding: '10px'}}
                                        />
                                </div>
                            </div>
                            <div className={styles.nationalite}>
                                <div className={styles.formElement}>
                                    <label htmlFor="autrePrenom" className={styles.label}>Autre Prénom</label>
                                    <input type="text" id={styles.autrePrenom} name="autrePrenom" className={styles.input}
                                        value={autrePrenom}
                                        onChange={(e) => setAutrePrenom(e.target.value)}
                                        style={{fontSize: '14px', padding: '10px'}}
                                        />
                                </div>
                                <div className={styles.formElement}>
                                    <label htmlFor="civilité" className={styles.label} aria-required="true">Civilité 
                                        <span className={styles.required}>*</span>
                                    </label>
                                    <input type="text" id={styles.civilite} name="civilité" className={styles.input}
                                        value={civilité}
                                        onChange={(e) => setCivilité(e.target.value)}
                                        style={{fontSize: '14px', padding: '10px'}}
                                        />
                                </div>
                            </div>
                        </div>
                    </div>
                        <div className={styles.nationalite}>
                            <div className={styles.formElement}>
                                <label htmlFor="dateNaissance" className={styles.label} aria-required="true">Date de naissance 
                                    <FontAwesomeIcon icon={faQuestion} className={styles.blueIcon}/>
                                    <span className={styles.required}>*</span>
                                </label>
                                <input type="date" id={styles.dateNaissance} name="dateNaissance" className={styles.input}
                                    value={dateNaissance}
                                    onChange={(e) => setDateNaissance(e.target.value)}
                                    style={{fontSize: '14px', padding: '10px'}}
                                    />
                            </div>

                            <div className={styles.formElement}>
                                <label htmlFor="paysNaissance" className={styles.label} aria-required="true">Pays de naissance 
                                    <span className={styles.required}>*</span>
                                </label>
                                <input type="text" id={styles.paysNaissance} name="paysNaissance" className={styles.input}
                                    value={paysNaissance}
                                    onChange={(e) => setPaysNaissance(e.target.value)}
                                    style={{fontSize: '14px', padding: '10px'}}
                                    />
                            </div>
                        </div>

                        <div className={styles.nationalite}>
                            <div className={styles.formElement}>
                                <label htmlFor="villeNaissance" className={styles.label} aria-required="true">Ville de naissance 
                                    <span className={styles.required}>*</span>
                                </label>
                                <input type="text" id={styles.villeNaissance} name="villeNaissance" className={styles.input}
                                    value={villeNaissance}
                                    onChange={(e) => setVilleNaissance(e.target.value)}
                                    style={{fontSize: '14px', padding: '10px'}}
                                />
                            </div>

                            <div className={styles.formElement}>
                                <label htmlFor="provinceNaissance" className={styles.label} >Province de naissance 
                                </label>
                                <input type="text" id={styles.provinceNaissance} name="provinceNaissance" className={styles.input}
                                    value={provinceNaissance}
                                    onChange={(e) => setProvinceNaissance(e.target.value)}
                                    style={{fontSize: '14px', padding: '10px'}}
                                />
                            </div>
                        </div>
                    <div className={styles.nationalite}>
                        <div className={styles.formElement}>
                            <label htmlFor="paysNationalite1" className={styles.label} aria-required="true">Nationalité 1
                                <FontAwesomeIcon icon={faQuestion} className={styles.blueIcon}/>
                                <span className={styles.required}>*</span>
                            </label>
                            <input type="text" id={styles.paysNationalite1} name="paysNationalite1" className={styles.input}
                                value={paysNationalite1}
                                onChange={(e) => setPaysNationalite1(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                                />
                        </div>
                        <div className={styles.formElement}>
                            <label htmlFor="paysNationalite2" className={styles.label}>Nationalité 2
                            </label>
                            <input type="text" id={styles.paysNationalite2} name="paysNationalite2" className={styles.input}
                                value={paysNationalite2}
                                onChange={(e) => setPaysNationalite2(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                                    />
                        </div>
                    </div>
                </div>
            </div>
            <div className={styles.contact}>
                <div className={styles.infosPersonnelles}>
                <div className={styles.contactDiv}>
                    <FontAwesomeIcon icon={faPenToSquare} className={styles.divIcon}/>
                    <h2>Contact</h2>
                </div>
                <div className={styles.contactInfos}>
                    <div className={styles.formElement}>
                        <label htmlFor="email" className={styles.label} aria-required="true">Email
                            <FontAwesomeIcon icon={faQuestion} className={styles.blueIcon}/>
                            <span className={styles.required}>*</span>
                        </label>
                        <input type="email" id={styles.email} name="email" className={styles.input}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            style={{fontSize: '14px', padding: '10px'}}
                        />
                    </div>
                    <div className={styles.telephone}>
                        <div className={styles.formElement}>
                            <label htmlFor="telephone" className={styles.label} aria-required="true">Téléphone 1
                                <span className={styles.required}>*</span>
                            </label>
                            <input type="tel" id={styles.telephone} name="telephone" className={styles.input}
                                value={telephone}
                                onChange={(e) => setTelephone(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                            />
                        </div>
                        <div className={styles.formElement}>
                            <label htmlFor="telephone2" className={styles.label}>Téléphone 2
                            </label>
                            <input type="tel" id={styles.telephone2} name="telephone2" className={styles.input}
                                value={telephone2}
                                onChange={(e) => setTelephone2(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                            />
                        </div>
                    </div>
                    <div className={styles.pays}>
                        <div className={styles.formElement}>
                            <label htmlFor="pays" className={styles.label} aria-required="true">Pays
                                <span className={styles.required}>*</span>
                            </label>
                            <input type="text" id={styles.pays} name="pays" className={styles.input}
                                value={pays}
                                onChange={(e) => setPays(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                            />
                        </div>
                        <div className={styles.formElement}>
                            <label htmlFor="ville" className={styles.label} aria-required="true">Ville
                                <span className={styles.required}>*</span>
                            </label>
                            <input type="text" id={styles.ville} name="ville" className={styles.input}
                                value={ville}
                                onChange={(e) => setVille(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                            />
                        </div>
                    </div>
                    <div className={styles.formElement}>
                        <label htmlFor="adresse" className={styles.label}>Adresse
                        </label>
                        <input type="text" id={styles.adresse} name="adresse" className={styles.input}
                            value={adresse}
                            onChange={(e) => setAdresse(e.target.value)}
                            style={{fontSize: '14px', padding: '10px'}}
                        />
                    </div>
                </div>
                </div>
                </div>
            <div className={styles.flotte}>
                <div className={styles.infosPersonnelles}>  
                <div className={styles.flotteDiv}>
                    <FontAwesomeIcon icon={faPenToSquare} className={styles.divIcon}/>
                    <h2>Flotte</h2>
                </div>
                <div className={styles.flotteInfos}>
                    <div className={styles.formElement}>
                        <label htmlFor="nomFlotte" className={styles.label} aria-required="true">Nom de la flotte
                            <FontAwesomeIcon icon={faQuestion} className={styles.blueIcon}/>
                            <span className={styles.required}>*</span>  
                        </label>
                        <input type="text" id={styles.nomFlotte} name="nomFlotte" className={styles.input}
                            value={nomFlotte}
                            onChange={(e) => setNomFlotte(e.target.value)}
                            style={{fontSize: '14px', padding: '10px'}}
                        />
                    </div>
                    <div className={styles.formElement}>
                        <label htmlFor="service" className={styles.label}>Service  
                        </label>
                        <input type="text" id={styles.service} name="service" className={styles.input}
                            value={service}
                            onChange={(e) => setService(e.target.value)}
                            style={{fontSize: '14px', padding: '10px'}}
                        />
                    </div>
                </div>
                </div>
                    <div className={styles.buttonDiv}>
                            <button type="submit" id={styles.button}>Enregistrer Les Informations</button>
                        </div>
                    </div>
            <div className={styles.permis}>
                <div className={styles.infosPersonnelles}>
                <div className={styles.permisDiv}>
                    <FontAwesomeIcon icon={faPenToSquare} className={styles.divIcon}/>
                    <h2>permis</h2>
                </div>
                <div className={styles.permisInfos}>
                    <div className={styles.permis}>
                        <div className={styles.formElement}>
                        <label htmlFor="permis" className={styles.label} aria-required="true">Type De Permis 
                            <FontAwesomeIcon icon={faQuestion} className={styles.blueIcon}/>
                            <span className={styles.required}>*</span>
                        </label>
                        <input type="number" id={styles.typePermis} name="typePermis" className={styles.input}
                            value={typePermis}
                            onChange={(e) => setTypePermis(e.target.value)}
                            style={{fontSize: '14px', padding: '10px'}}
                        />
                    </div>
                        <div className={styles.formElement}>
                            <label htmlFor="permis" className={styles.label} aria-required="true">Date D'obtention 
                                <span className={styles.required}>*</span>
                            </label>
                            <input type="date" id={styles.dateObtention} name="dateObtention" className={styles.input}
                                value={dateObtention}
                                onChange={(e) => setDateObtention(e.target.value)}
                                style={{fontSize: '14px', padding: '10px'}}
                            />
                        </div>
                    </div>
                </div>
                </div>
                </div>
        </form>
    );
}   