import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown, faSearch, faSignOutAlt, faTruck, faUser } from "@fortawesome/free-solid-svg-icons";
import styles from './MenuBar.module.css';

export default function MenuBar() {
    return (
        <div 
            style={
                {
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    backgroundColor: '#0D47A1',
                    color: 'white',
                    padding: '10px',
                    borderRadius: '10px',
                    }}>
            <img src="/images/logo.png" alt="Logo" width={80} height={80}/>
                <div    className={styles.MenuBarElement} 
                    style={{
                    display: 'flex',
                    alignItems: 'center',
                    }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        backgroundColor: '#FF7A00',
                        color: 'white',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold',
                        }}>
                        M   
                    </div >
                    <h2>Mon Dashboard</h2>
                    <FontAwesomeIcon icon={faChevronDown}
                        style={
                            {
                                color: '#FF7A00',
                                width: 40,
                                height: 40,
                            }
                        }
                    />
                </div>

            {/* le nom de la flotte */}
                <div className={styles.MenuBarElement}
                    style={
                        {
                            display: 'flex',
                            alignItems: 'center',
                            }}>
                    <FontAwesomeIcon icon={faTruck}
                        style={
                            {
                                color: '#FF7A00',
                                width: 40,
                                height: 40,
                            }
                        }
                    />
                    <h2>Nom de la flotte</h2>
                </div>
            {/* barre de recherche */}
                <div className={styles.MenuBarElement}
                    style={
                        {
                            display: 'flex',
                            alignItems: 'center',
                            }}>
                    <FontAwesomeIcon icon={faSearch}
                        style={
                            {
                                color: '#FF7A00',
                                width: 40,
                                height: 40,
                            }
                        }
                    />
                    <h2>Rechercher</h2>
                </div>
            {/* aller sur son profil utilisateur */}
                <div className={styles.MenuBarElement}
                    style={
                        {
                            display: 'flex',
                            alignItems: 'center',
                            }}>
                    <FontAwesomeIcon icon={faUser}
                        style={
                            {
                                color: '#FF7A00',
                                width: 40,
                                height: 40,
                            }
                        }
                    />
                    <h2>Mon profil</h2>
                </div>
            {/* bouton de deconnexion */}
                <div className={styles.MenuBarElement}
                        style={
                        {
                            display: 'flex',
                            alignItems: 'center',
                            }}>
                    <FontAwesomeIcon icon={faSignOutAlt}
                        style={
                            {
                                color: '#FF7A00',
                                width: 40,
                                height: 40,
                            }
                        }
                    />
                    <h2>Me déconnecter</h2>
                </div>
        </div>
    );
}